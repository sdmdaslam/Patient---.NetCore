﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Patients.Models
{
    public interface IPatientDataLayer
    {
        IEnumerable<PatientDetails> GetAllPatients();
        void AddPatient(PatientDetails patient);
        void UpdatePatient(PatientDetails patient);
        PatientDetails GetPatientData(int? id);
        void DeletePatient(int? id);
    }
}
