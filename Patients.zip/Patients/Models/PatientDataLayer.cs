﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Patients.Models
{
    public class PatientDataLayer: IPatientDataLayer
    {
        private readonly List<PatientDetails> patients;
        private IConfiguration _configuration;
        public PatientDataLayer(IConfiguration configuration)
        {
            _configuration = configuration;
            patients = new List<PatientDetails>()
            {
                new PatientDetails(){ID=1, FirstName = "John", LastName="Donovan", DateOfBirth=DateTime.Parse("1/2/1985"),Gender="Male",StreetAddress="No 1 Main Road",City="Delhi",ZipCode=12345,Mobile=123456789,EmergencyContact=987654321,EMail="xyz@rte.com",PhysicianName="Dr.Alfonse"},
                new PatientDetails(){ID=2, FirstName="Sherlock",LastName="Holmes", DateOfBirth=DateTime.Parse("12/2/1985"),Gender="Male",StreetAddress="No 2 South Street",City="Chennai",ZipCode=54321,Mobile=123456789,EmergencyContact=987654321,EMail="yut@hut.com",PhysicianName="Dr.Alfonse"}
            };
        }
         
        public IEnumerable<PatientDetails> GetAllPatients()
        {           
            //List<PatientDetails> lstPatients = new List<PatientDetails>();

            return patients;
            //using (SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            //{
            //    SqlCommand cmd = new SqlCommand("Select * from PatientDetails", con);
            //    cmd.CommandType = CommandType.Text;
            //    con.Open();
            //    SqlDataReader reader = cmd.ExecuteReader();
            //    while (reader.Read())
            //    {
            //        PatientDetails patient = new PatientDetails();
            //        patient.ID = Convert.ToInt32(reader["PatientID"]);
            //        patient.FirstName = reader["FirstName"].ToString();
            //        patient.LastName = reader["LastName"].ToString();
            //        patient.DateOfBirth = Convert.ToDateTime(reader["DateOfBirth"]);
            //        patient.Gender = reader["Gender"].ToString();
            //        patient.StreetAddress = reader["StreetAddress"].ToString();
            //        patient.City = reader["City"].ToString();
            //        patient.ZipCode = Convert.ToInt32(reader["ZipCode"]);
            //        patient.Mobile = Convert.ToInt64(reader["Mobile"]);
            //        patient.EmergencyContact = Convert.ToInt64(reader["EmergencyContact"]);
            //        patient.EMail = reader["EMail"].ToString();
            //        patient.PhysicianName = reader["PhysicianName"].ToString();
            //        lstPatients.Add(patient);
            //    }
            //    con.Close();
            //}
            //return lstPatients;
        }

        public void AddPatient(PatientDetails patient)
        {
            int numberofPatient = patients.Count;
            patient.ID = ++numberofPatient;
            patients.Add(patient);


            //using (SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            //{
            //    SqlCommand cmd = new SqlCommand(@"INSERT INTO PatientDetails(FirstName,LastName,DateOfBirth,Gender,StreetAddress,City,ZipCode,Mobile,EmergencyContact,EMail,PhysicianName) 
            //                                    VALUES(@FirstName,@LastName,@DateOfBirth,@Gender,@StreetAddress,@City,@ZipCode,@Mobile,@EmergencyContact,@EMail,@PhysicianName)", con);
            //    cmd.CommandType = CommandType.Text;
            //    cmd.Parameters.AddWithValue("@FirstName", patient.FirstName);
            //    cmd.Parameters.AddWithValue("@LastName", patient.LastName);
            //    cmd.Parameters.AddWithValue("@DateOfBirth", patient.DateOfBirth);
            //    cmd.Parameters.AddWithValue("@Gender", patient.Gender);
            //    cmd.Parameters.AddWithValue("@StreetAddress", patient.StreetAddress);
            //    cmd.Parameters.AddWithValue("@City", patient.City);
            //    cmd.Parameters.AddWithValue("@ZipCode", patient.ZipCode);
            //    cmd.Parameters.AddWithValue("@Mobile", patient.Mobile);
            //    cmd.Parameters.AddWithValue("@EmergencyContact", patient.EmergencyContact);
            //    cmd.Parameters.AddWithValue("@EMail", patient.EMail);
            //    cmd.Parameters.AddWithValue("@PhysicianName", patient.PhysicianName);
            //    con.Open();
            //    cmd.ExecuteNonQuery();
            //    con.Close();
            //}
        }

        public void UpdatePatient(PatientDetails patient)
        {
            PatientDetails updatePatientDetails = patients.SingleOrDefault(pat => pat.ID == patient.ID);
            patients.Remove(updatePatientDetails);
            patients.Add(patient);
            //using (SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            //{
            //    SqlCommand cmd = new SqlCommand(@"UPDATE PatientDetails SET FirstName = @FirstName,
            //        LastName = @LastName,
            //        DateOfBirth = @DateOfBirth,
            //        Gender = @Gender,
            //        StreetAddress = @StreetAddress,
            //        City = @City,
            //        ZipCode = @ZipCode,
            //        Mobile = @Mobile,
            //        EmergencyContact = @EmergencyContact,
            //        EMail = @EMail,
            //        PhysicianName = @PhysicianName Where PatientId = @PatientID", con);
            //    cmd.CommandType = CommandType.Text;
            //    cmd.Parameters.AddWithValue("@FirstName", patient.FirstName);
            //    cmd.Parameters.AddWithValue("@LastName", patient.LastName);
            //    cmd.Parameters.AddWithValue("@DateOfBirth", patient.DateOfBirth);
            //    cmd.Parameters.AddWithValue("@Gender", patient.Gender);
            //    cmd.Parameters.AddWithValue("@StreetAddress", patient.StreetAddress);
            //    cmd.Parameters.AddWithValue("@City", patient.City);
            //    cmd.Parameters.AddWithValue("@ZipCode", patient.ZipCode);
            //    cmd.Parameters.AddWithValue("@Mobile", patient.Mobile);
            //    cmd.Parameters.AddWithValue("@EmergencyContact", patient.EmergencyContact);
            //    cmd.Parameters.AddWithValue("@EMail", patient.EMail);
            //    cmd.Parameters.AddWithValue("@PhysicianName", patient.PhysicianName);
            //    cmd.Parameters.AddWithValue("@PatientID", patient.ID);
            //    con.Open();
            //    cmd.ExecuteNonQuery();

            //}
        }

        public PatientDetails GetPatientData(int? id)
        {
            PatientDetails patient = patients.SingleOrDefault(x => x.ID == id);

            //using (SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            //{
            //    string sqlQuery = "SELECT * FROM PatientDetails WHERE PatientID= @PatientID";
            //    SqlCommand cmd = new SqlCommand(sqlQuery, con);
            //    cmd.CommandType = CommandType.Text;
            //    cmd.Parameters.AddWithValue("@PatientID", id);
            //    con.Open();
            //    SqlDataReader reader = cmd.ExecuteReader();
            //    while (reader.Read())
            //    {
            //        patient.ID = Convert.ToInt32(reader["PatientID"]);
            //        patient.FirstName = reader["FirstName"].ToString();
            //        patient.LastName = reader["LastName"].ToString();
            //        patient.DateOfBirth = Convert.ToDateTime(reader["DateOfBirth"]);
            //        patient.Gender = reader["Gender"].ToString();
            //        patient.StreetAddress = reader["StreetAddress"].ToString();
            //        patient.City = reader["City"].ToString();
            //        patient.ZipCode = Convert.ToInt32(reader["ZipCode"]);
            //        patient.Mobile = Convert.ToInt64(reader["Mobile"]);
            //        patient.EmergencyContact = Convert.ToInt64(reader["EmergencyContact"]);
            //        patient.EMail = reader["EMail"].ToString();
            //        patient.PhysicianName = reader["PhysicianName"].ToString();



            //    }
            //}
            return patient;
        }
        
        public void DeletePatient(int? id)
        {
            PatientDetails patient = patients.SingleOrDefault(x => x.ID == id);
            patients.Remove(patient);
            //using (SqlConnection con = new SqlConnection(_configuration.GetConnectionString("DefaultConnection")))
            //{
            //    SqlCommand cmd = new SqlCommand("DELETE FROM PatientDetails WHERE PatientID = @PatientID", con);
            //    cmd.CommandType = CommandType.Text;
            //    cmd.Parameters.AddWithValue("@PatientID", id);
            //    con.Open();
            //    cmd.ExecuteNonQuery();                
            //}
        }
    }
}
