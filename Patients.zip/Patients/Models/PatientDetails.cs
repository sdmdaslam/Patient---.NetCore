﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Patients.Models
{
    public class PatientDetails
    {
        public int ID { get; set; }
        [Required]
        public string FirstName { get; set; }

        public string LastName { get; set; }

        [Required]
        public DateTime DateOfBirth { get; set; }

        [Required]
        public string Gender { get; set; }
        [Required]
        public string StreetAddress { get; set; }
        [Required]
        public string City { get; set; }

        public int ZipCode { get; set; }

        [Required]        
        public long Mobile { get; set; }
        [Required]
        public long EmergencyContact{get;set;}
        [Required]
        [RegularExpression(@"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$",ErrorMessage ="Invalid Email Format")]
        public string EMail { get; set; }
        public string PhysicianName { get; set; }
    }
}
