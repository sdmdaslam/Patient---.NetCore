﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Patients.Models;

namespace Patients.Controllers
{
    public class PatientController : Controller
    {
        PatientDataLayer patientDataLayer = new PatientDataLayer();
        public IActionResult PatientDashboard()
        {
            List<PatientDetails> lstPatient = new List<PatientDetails>();
            lstPatient = patientDataLayer.GetAllPatients().ToList();
            return View(lstPatient);
        }

        [HttpGet]
        public IActionResult EditPatient(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            PatientDetails patientDetails = patientDataLayer.GetPatientData(id);
            if (patientDetails == null)
            {
                return NotFound();
            }
            return View(patientDetails);
        }
        [HttpPost]
        public IActionResult Edit(int id, [Bind]PatientDetails patient)
        {
            if (id != patient.ID)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                patientDataLayer.UpdatePatient(patient);
                return RedirectToAction("PatientDashboard");
            }
            return View(patient);
        }

        [HttpGet]
        public IActionResult PatientDetails(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            PatientDetails patient = patientDataLayer.GetPatientData(id);
            if (patient == null)
            {
                return NotFound();
            }
            return View(patient);
        }

        [HttpGet]
        public IActionResult AddPatient()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddPatient(PatientDetails patient)
        {
            if (ModelState.IsValid)
            {
                patientDataLayer.AddPatient(patient);
                return RedirectToAction("Index");
            }
            return View(patient);
        }

        [HttpGet]
        public IActionResult DeletePatient(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            PatientDetails patient = patientDataLayer.GetPatientData(id);
            if (patient == null)
            {
                return NotFound();
            }
            return View(patient);
        }
        [HttpPost, ActionName("DeletePatient")]
        [ValidateAntiForgeryToken]
        public IActionResult DeletePatientConfirmed(int? id)
        {
            patientDataLayer.DeletePatient(id);
            return RedirectToAction("PatientDashboard");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
