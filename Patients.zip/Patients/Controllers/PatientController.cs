﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Patients.Models;

namespace Patients.Controllers
{
    public class PatientController : Controller
    {
        private readonly IPatientDataLayer _patientDataLayer;
        public PatientController(IPatientDataLayer patientDataLayer)
        {
            _patientDataLayer = patientDataLayer;
        }
       
        public IActionResult PatientDashboard()
        {
            List<PatientDetails> lstPatient;
            lstPatient = _patientDataLayer.GetAllPatients().ToList();
            return View(lstPatient);
        }

        [HttpGet]
        public IActionResult EditPatient(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            PatientDetails patientDetails = _patientDataLayer.GetPatientData(id);
            if (patientDetails == null)
            {
                return NotFound();
            }
            return View(patientDetails);
        }
        [HttpPost]
        public IActionResult Edit(int id, [Bind]PatientDetails patient)
        {
            if (id != patient.ID)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                _patientDataLayer.UpdatePatient(patient);
                return RedirectToAction("PatientDashboard");
            }
            return View(patient);
        }

        [HttpGet]
        public IActionResult PatientDetails(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            PatientDetails patient = _patientDataLayer.GetPatientData(id);
            if (patient == null)
            {
                return NotFound();
            }
            return View(patient);
        }

        [HttpGet]
        public IActionResult AddPatient()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddPatient(PatientDetails patient)
        {
            if (ModelState.IsValid)
            {
                _patientDataLayer.AddPatient(patient);
                return RedirectToAction("PatientDashboard");
            }
            return View(patient);
        }

        [HttpGet]
        public IActionResult DeletePatient(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            PatientDetails patient = _patientDataLayer.GetPatientData(id);
            if (patient == null)
            {
                return NotFound();
            }
            return View(patient);
        }
        [HttpPost, ActionName("DeletePatient")]
        [ValidateAntiForgeryToken]
        public IActionResult DeletePatientConfirmed(int? id)
        {
            _patientDataLayer.DeletePatient(id);
            return RedirectToAction("PatientDashboard");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
